//
//  ViewController.swift
//  AlamofireExample
//
//  Created by hardik aghera on 24/04/18.
//  Copyright © 2018 hardikaghera2306. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    @IBOutlet var tblJSON: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
      alamofireRequest()
          //jsonparsing()
        
}
 
    func alamofireRequest () {
        let newsURL = "https://newsapi.org/v2/top-headlines?sources=cbc-news&apiKey=4ecad697b0f24c748a842dfb9a7be4fe"
        Alamofire.request(newsURL).validate().responseJSON{ response in
         //   print(response)
            if let value = response.result.value {
                let json = JSON(value)
             //   print(json)
            let articles = json["articles"].arrayValue
              //  print(articles)
            let title = json["articles"].arrayValue.map({$0["title"].stringValue})
                print(title)
            let firstTitle = json["articles"][0]["title"].stringValue
             //   print(firstTitle)
            }
        }
    }
    
    func jsonparsing(){
        
        let url = URL(string: "https://newsapi.org/v2/top-headlines?sources=cbc-news&apiKey=4ecad697b0f24c748a842dfb9a7be4fe")
        if let usableUrl = url {
            let request = URLRequest(url: usableUrl)
            let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
                if error != nil{
                    print("error is ",error!)
                    return
                }
                do{
                    let myJSON = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    print(myJSON)
                    
                    if let articledata = myJSON["articles"] as? [NSDictionary]{
                        print(articledata[0]["title"]!)
                    }
                }
                catch let error{
                    print(error)
                }
            })
            task.resume()
        }
    }
}

