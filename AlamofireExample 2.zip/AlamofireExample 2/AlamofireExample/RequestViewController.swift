//
//  RequestViewController.swift
//  AlamofireExample
//
//  Created by Hardik Aghera on 09/05/18.
//  Copyright © 2018 hardikaghera2306. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class RequestViewController: UIViewController {
    let parameters: [String: Any] = [
        "IdQuiz" : 102,
        "IdUser" : "iosclient",
        "List": [
            [
                "IdQuestion" : 5,
                "IdProposition": 2,
                "Time" : 32
            ],
            [
                "IdQuestion" : 4,
                "IdProposition": 3,
                "Time" : 9
            ]
        ]
    ]
    override func viewDidLoad() {
        super.viewDidLoad()

        let URL = "https://jsonplaceholder.typicode.com/posts"
        Alamofire.request(URL,method:.post,parameters:parameters).responseJSON{ response in
            print(response)
        }
    }
}
