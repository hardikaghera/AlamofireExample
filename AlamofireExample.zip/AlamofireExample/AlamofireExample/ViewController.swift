//
//  ViewController.swift
//  AlamofireExample
//
//  Created by hardik aghera on 24/04/18.
//  Copyright © 2018 hardikaghera2306. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController,UITableViewDelegate {
    @IBOutlet var tblJSON: UITableView!
    var arrRes = [[String:AnyObject]]() //Array of dictionary

    override func viewDidLoad() {
        super.viewDidLoad()
        tblJSON.delegate = self
        
//        Alamofire.request("https://itunes.apple.com/search?media=music&term=bollywood").responseJSON { (responseData) -> Void in
//            if((responseData.result.value) != nil) {
//                let swiftyJsonVar = JSON(responseData.result.value!)
//
//                if let resData = swiftyJsonVar["results"].arrayObject {
//                    self.arrRes = resData as! [[String:AnyObject]]
//                }
//                if let nameData = swiftyJsonVar[0]["results"]["artistId"].int {
//                    print(nameData)
//                    print(swiftyJsonVar[0]["results"]["artistId"])
//
//                }
//                if self.arrRes.count > 0 {
//                    self.tblJSON.reloadData()
//                }
//             //   print(self.arrRes)
//            }
//        }
        
        Alamofire.request("https://itunes.apple.com/search?media=music&term=bollywood") .responseJSON { response in
            if let value = response.result.value {
                let json = JSON(value)
            //    print(json.arrayValue)
                let result = json["results"].arrayValue
           //     print(result)
                for (key,subJson) in json["results"] {
                    if let artistid = subJson["artistId"].int {
                      //  print(artistid)
                    if let artistName = subJson["artistName"].string {
                        print(artistName)
                        }
                        
                    }
                    
                }
                
        }
        
    }

//    private func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: IndexPath) -> UITableViewCell {
//        let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
//        var dict = arrRes[indexPath.row]
//        cell.textLabel?.text = dict["name"] as? String
//        cell.detailTextLabel?.text = dict["email"] as? String
//        return cell
//    }
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return arrRes.count
//    }


}
}
