//
//  contactsTableViewCell.swift
//  AlamofireExample
//
//  Created by hardik aghera on 28/04/18.
//  Copyright © 2018 hardikaghera2306. All rights reserved.
//

import UIKit

class contactsTableViewCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
